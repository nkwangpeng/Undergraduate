var flag = false;
function clearBaiduSearchAD() {   
    
    var rightad = document.getElementById("ec_im_container");
    if (rightad) {
        rightad.parentNode.removeChild(rightad);
        flag = 1;
    }//网页右侧广告

    [].forEach.call(document.body.querySelectorAll("#content_left>div,#content_left>table"), function(e) {
        var ht = e.getAttribute("style");
        if (ht && /display:(table|block)\s!important/.test(ht)) {
            e.parentNode.removeChild(e);
            flag = 1;
        }
    });  //头部与尾部的推广

        Array.prototype.forEach.call(document.body.querySelectorAll("#content_right>div>div>h3"), function (e) {
        if (e) {
            var temp = e.parentNode.parentNode;
            temp.parentNode.removeChild(temp);
            flag = 1;
        }
    })//右边广告图片

    Array.prototype.forEach.call(document.body.querySelectorAll(".c-container /deep/ .c-container"), function(ad) {         
        if (ad) {
            ad.parentNode.removeChild(ad);
            flag = 1;
        }
    }); //搜索结果头部

   
    Array.prototype.forEach.call(document.body.querySelectorAll("#content_left>div>div>span"), function(e) {
        var title = e.innerText;
        var x=e.parentNode.parentNode;
        if (title=="广告") {
            x.parentNode.removeChild(x);
            flag = 1;
        }
    }); //直接检索广告
}
//以下部分改成通过多次调用来把广告去掉
clearBaiduSearchAD();
//当点击搜索时候调用
document.getElementById("su").addEventListener('click', function () {
    setTimeout(clearBaiduSearchAD, 1000);
}, false);
//当搜索栏搜索时候调用
document.getElementById("kw").addEventListener('keyup', function () {
    setTimeout(clearBaiduSearchAD, 1000);
}, false);
//当广告那栏发生变化则调用
document.getElementById("container").addEventListener('DOMSubtreeModified', function () {
    setTimeout(clearBaiduSearchAD, 0);
}, false);
//页面加载调用
window.onload = function () {
    this.setTimeout(this.clearBaiduSearchAD(), 1000);
}
//页面滑动时候调用
window.onscroll = function () {
    this.setTimeout(this.clearBaiduSearchAD, 0);
}
//页面鼠标移动调用
document.body.onmousemove = function () {
    setTimeout(clearBaiduSearchAD, 0);
}